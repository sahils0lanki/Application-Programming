"""
Application Program:        Lab05.py
Programmer name:            Sahil Solanki
Dated:                      October 9th, 2022

This application is a student registration systems. It enrolls a student in course and adds information about students
like name, student id, marks and average in the course. It displays all details by searching by their student id.
"""
import os.path
def header():
    print("%130s" % "Sahil Solanki")
    print("%130s" % "N01498358")
    print("%30s%20s%20s%22s%20s%20s"%("Name","Student ID", "Course", "Test 1 ", "Test 2 ", "Average"))
    return

def inputs():
    input = """1. Register Student
2. Display all registered students
3. Search student by student ID
4. End application
    """
    print(input)
    return



def input_data(): #all data and information about students
    student_name = input("Enter Student's Name:\t")
    student_no = input("Enter Student ID:\t")
    student_course = input("Enter Student Course:\t")
    stu_present = False                     #variable to check the
    while True:  # Only allow floating point numbers input into the marks variables
        try:
            mark_1 = float(input("Enter Marks for Test 1:\t"))
            mark_2 = float(input("Enter Marks for Test 2:\t"))
            if mark_1>=0 and mark_1<=100 and mark_2>=0 and mark_2 <=100:
                break
            else:
                print("Invalid input\nOnly values between 0 to 100 allowed")
        except:
            print("Only Numbers Allowed in Marks! Try Again...")

    avg_marks = (mark_1 + mark_2)/2
    data_input = "\n"+student_name + ":" + student_no + ":"+ student_course +":" + str(mark_1) + ":" + str(mark_2) + ":" + str(avg_marks)
    print(data_input)
    file = open('data.txt', 'r')
    for data in file:
        data = data.strip()
        indv_data = data.split(':')

        if indv_data[1] == str(student_no):            #Check for student Id already present in the file or not
            stu_present = True
            print("Student already Registered....Cannot Register again...")
            file.close()
            break
    file.close()

    if stu_present == False:
        print(f"Student with Student ID {student_no} is NOT enrolled or registered yet\nRegistering student with student ID {student_no}\n")
        file = open('data.txt', 'a')
        file.write(data_input)
        file.close()
    return



def display_data():
    file = open('data.txt', 'r')
    header()
    for data in file:
        data = data.strip()
        indv_data = data.split(':')
        print("%30s%20s%20s%20s%20s%20s"%(indv_data[0],indv_data[1],indv_data[2],indv_data[3],indv_data[4],indv_data[5]))
    return

def search(): #student info by student id
    stu_number = input("Please enter Registered Student ID to search for student information: ")
    file = open("data.txt", 'r')
    for data in file:
        data = data.strip()
        indv_data = data.split(':')
        if indv_data[1] == stu_number:
            print("Student Registered in the system")

            header()

            print("%30s%20s%20s%20s%20s%20s\n" % (indv_data[0], indv_data[1], indv_data[2], indv_data[3], indv_data[4], indv_data[5]))
            break
        else:
            print(f"Student having Student ID {stu_number} not enrolled in the system")

    file.close()
    return


def main():
    if os.path.isfile('./' + 'data.txt') == True:
        while True:
            if os.path.getsize('./' + 'data.txt') > 0:
                inputs()
                choice = input("Enter your choice: ")
                if choice == '1':
                    input_data()
                elif choice == '2':
                    display_data()
                elif choice =='3':
                    search()
                elif choice =='4':
                    print("Application Ending Now....")
                    break
                else:
                    print("Invalid Input!")


            else:
                print("There is no data in the file")
                student_name = input("Enter Student's Name:")  # Taking student data input
                student_no = input("Enter Student ID:")
                student_course = input("Enter Student Course:")
                while True:  # Only allow float input into the marks variables
                    try:
                        mark_1 = float(input("Enter Marks for Test 1:"))
                        mark_2 = float(input("Enter Marks for Test 2:"))
                        break
                    except:
                        print("Only Numbers Allowed in Marks! Try Again...")

                avg_marks = (mark_1 + mark_2) / 2
                # Appendinng data to file
                data_input = student_name + ":" + student_no + ":" + student_course + ":" + str(mark_1) + ":" + str(
                    mark_2) + ":" + str(avg_marks)
                print(f"Registering student with student ID {student_no}\n")
                file = open('data.txt', 'a')
                file.write(data_input)
                file.close()

    else:
        print("File does not exist")

main()




